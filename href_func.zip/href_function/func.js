function link() {
  document.body.innerHTML='';
  var href = "<a href='http://mysite.com'>CLICK ME TOO</a>";
  document.write(href);
}
